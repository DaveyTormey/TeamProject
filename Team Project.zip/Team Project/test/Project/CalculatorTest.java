/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package Project;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ryanl
 */
public class CalculatorTest {
    
    public CalculatorTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of main method, of class Calculator.
     */
    @Test
    public void testAdd() {
        System.out.println("Add");
        double num1 = 1;
        double num2 = 1;
        Calculator instance = new Calculator();
        double expResult = 2;
        double result = instance.add(num1, num2);
        assertEquals(expResult, result, 0.0);
    }
    

    @Test
    public void testSubtract() {
        System.out.println("Subtract");
        double num1 = 1;
        double num2 = 1;
        Calculator instance = new Calculator();
        double expResult = 0;
        double result = instance.subtract(num1, num2);
        assertEquals(expResult, result, 0.0);
    }
    
    @Test
    public void testMultiply(){
        System.out.println("Multiply");
        double num1 = 1;
        double num2 = 1;
        Calculator instance = new Calculator();
        double expResult = 1;
        double result = instance.multiply(num1, num2);
        assertEquals(expResult, result, 0.0);
    }
    
    @Test
    public void testDivide(){
        System.out.println("Divide");
        double num1 = 1;
        double num2 = 1;
        Calculator instance = new Calculator();
        double expResult = 1;
        double result = instance.divide(num1,num2);
        assertEquals(expResult, result, 0.0);
    }



    
}
