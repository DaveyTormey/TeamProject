As our project didn't use any external databases there are 2 sections that you need to change to a local address of your PC to save the .txt file.

First: Login.java line 29
Second: notesPage.java line 21
Third: calendarPage.java line 23

In order to view the app, go to the main folder and go to the 'dist' subfolder and execute the .jar file to get to the login screen.
